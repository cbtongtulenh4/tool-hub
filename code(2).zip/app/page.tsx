"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Sidebar } from "@/components/sidebar"
import { SetupPanel } from "@/components/setup-panel"
import { LogViewer } from "@/components/log-viewer"
import { DeviceViewer } from "@/components/device-viewer"

export default function Home() {
  const [logs, setLogs] = useState<string[]>([
    "[INFO] System initialized",
    "[INFO] Waiting for project configuration...",
  ])
  const [isRunning, setIsRunning] = useState(false)

  const handleRunTest = (data: any) => {
    setIsRunning(true)
    setLogs((prev) => [
      ...prev,
      `[START] Running tests from: ${data.projectPath}`,
      `[START] Device: ${data.device}`,
      `[INFO] Executing ${data.testcases.length} test cases...`,
    ])
  }

  return (
    <div className="flex h-screen bg-background text-foreground">
      <Sidebar />
      <div className="flex flex-1 flex-col">
        <Header />
        <main className="flex-1 overflow-auto p-6">
          <div className="space-y-6">
            <SetupPanel onRunTest={handleRunTest} isRunning={isRunning} />

            <div className="grid grid-cols-3 gap-6 h-96">
              <div className="col-span-2">
                <LogViewer logs={logs} />
              </div>
              <div className="col-span-1">
                <DeviceViewer />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
