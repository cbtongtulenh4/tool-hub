import { Smartphone } from "lucide-react"

export function DeviceViewer() {
  return (
    <div className="rounded-lg border border-border bg-card overflow-hidden flex flex-col h-full">
      <div className="px-4 py-3 border-b border-border bg-background/50 flex items-center gap-2">
        <Smartphone className="w-4 h-4" />
        <h3 className="text-sm font-semibold text-foreground">Device View</h3>
      </div>

      <div className="flex-1 flex items-center justify-center bg-slate-950 p-4">
        <div className="w-full aspect-video bg-slate-900 rounded-lg flex items-center justify-center border border-border">
          <div className="text-center">
            <Smartphone className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-50" />
            <p className="text-xs text-muted-foreground">Chờ stream từ thiết bị...</p>
          </div>
        </div>
      </div>
    </div>
  )
}
