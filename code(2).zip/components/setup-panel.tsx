"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Folder, Plus, Trash2, Play, RotateCw, Trash } from "lucide-react"

interface SetupPanelProps {
  onRunTest: (data: any) => void
  isRunning: boolean
}

export function SetupPanel({ onRunTest, isRunning }: SetupPanelProps) {
  const [projectPath, setProjectPath] = useState("")
  const [device, setDevice] = useState("device1")
  const [testcases, setTestcases] = useState<string[]>(["test_login.py", "test_checkout.py"])
  const [newTestcase, setNewTestcase] = useState("")

  const devices = [
    { id: "device1", name: "Samsung Galaxy S21" },
    { id: "device2", name: "Pixel 6 Pro" },
    { id: "device3", name: "OnePlus 9" },
  ]

  const handleAddTestcase = () => {
    if (newTestcase.trim()) {
      setTestcases([...testcases, newTestcase])
      setNewTestcase("")
    }
  }

  const handleRemoveTestcase = (index: number) => {
    setTestcases(testcases.filter((_, i) => i !== index))
  }

  return (
    <div className="rounded-lg border border-border bg-card p-6">
      <h2 className="text-lg font-semibold text-foreground mb-6">Thiết lập dự án</h2>

      <div className="grid grid-cols-2 gap-6 mb-6">
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Đường dẫn dự án</label>
          <div className="flex gap-2">
            <Input
              type="text"
              placeholder="/path/to/project"
              value={projectPath}
              onChange={(e) => setProjectPath(e.target.value)}
              className="flex-1"
            />
            <Button variant="outline" size="icon">
              <Folder className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Chọn thiết bị</label>
          <select
            value={device}
            onChange={(e) => setDevice(e.target.value)}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-foreground text-sm"
          >
            {devices.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="space-y-3 mb-6">
        <div className="flex items-center justify-between">
          <label className="text-sm font-medium text-foreground">Danh sách Test Cases</label>
          <span className="text-xs text-muted-foreground">{testcases.length} test(s)</span>
        </div>

        <div className="flex gap-2 mb-3">
          <Input
            type="text"
            placeholder="Nhập tên test case (vd: test_name.py)"
            value={newTestcase}
            onChange={(e) => setNewTestcase(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleAddTestcase()}
            className="flex-1"
          />
          <Button onClick={handleAddTestcase} variant="outline" size="icon">
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        <div className="max-h-32 overflow-y-auto space-y-2 bg-background rounded-md p-3 border border-input">
          {testcases.length > 0 ? (
            testcases.map((tc, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between px-3 py-2 bg-card rounded border border-border text-sm"
              >
                <span className="font-mono text-foreground">{tc}</span>
                <button
                  onClick={() => handleRemoveTestcase(idx)}
                  className="text-destructive hover:text-destructive/80"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          ) : (
            <p className="text-center text-muted-foreground text-sm py-4">Chưa có test case nào</p>
          )}
        </div>
      </div>

      <div className="flex gap-3">
        <Button
          onClick={() =>
            onRunTest({
              projectPath,
              device,
              testcases,
            })
          }
          disabled={!projectPath || testcases.length === 0 || isRunning}
          className="flex-1 gap-2"
        >
          <Play className="w-4 h-4" />
          {isRunning ? "Đang chạy..." : "Chạy Test"}
        </Button>
        <Button variant="outline" className="gap-2 bg-transparent" disabled={!isRunning}>
          <Trash className="w-4 h-4" />
          Dừng
        </Button>
        <Button variant="ghost" className="gap-2">
          <RotateCw className="w-4 h-4" />
          Làm mới
        </Button>
      </div>
    </div>
  )
}
