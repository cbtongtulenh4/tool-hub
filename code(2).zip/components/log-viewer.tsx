import { RotateCw, Copy } from "lucide-react"
import { Button } from "@/components/ui/button"

interface LogViewerProps {
  logs: string[]
}

export function LogViewer({ logs }: LogViewerProps) {
  return (
    <div className="rounded-lg border border-border bg-card overflow-hidden flex flex-col h-full">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-background/50">
        <h3 className="text-sm font-semibold text-foreground">Console Log</h3>
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" className="gap-1">
            <Copy className="w-3 h-3" />
            Copy
          </Button>
          <Button variant="ghost" size="sm" className="gap-1">
            <RotateCw className="w-3 h-3" />
            Clear
          </Button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 font-mono text-xs bg-slate-950 text-slate-100 space-y-1">
        {logs.length > 0 ? (
          logs.map((log, idx) => (
            <div key={idx} className="text-slate-300 hover:bg-slate-900/50 px-2 py-0.5">
              {log}
            </div>
          ))
        ) : (
          <p className="text-slate-500">Chưa có log nào</p>
        )}
      </div>
    </div>
  )
}
