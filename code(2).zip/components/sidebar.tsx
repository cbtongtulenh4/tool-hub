"use client"

import { useState } from "react"
import { Smartphone, Play, History, Settings } from "lucide-react"

const menuItems = [
  { icon: Smartphone, label: "Thiết bị của tôi", id: "devices" },
  { icon: Play, label: "Chạy test", id: "run" },
  { icon: History, label: "Lịch sử", id: "history" },
  { icon: Settings, label: "Cài đặt", id: "settings" },
]

export function Sidebar() {
  const [active, setActive] = useState("run")

  return (
    <aside className="w-64 border-r border-border bg-sidebar">
      <div className="p-4">
        <p className="text-xs uppercase tracking-wider text-sidebar-foreground/60 font-semibold mb-4">Menu</p>
        <nav className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon
            return (
              <button
                key={item.id}
                onClick={() => setActive(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  active === item.id
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            )
          })}
        </nav>
      </div>
    </aside>
  )
}
