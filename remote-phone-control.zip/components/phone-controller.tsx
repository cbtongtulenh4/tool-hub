"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Home, Square, VolumeX, Volume2, Smartphone, Activity, Wifi } from "lucide-react"

export default function PhoneController() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [connected, setConnected] = useState(false)
  const [fps, setFps] = useState(0)
  const [ping, setPing] = useState(0)
  const [device, setDevice] = useState<USBDevice | null>(null)
  const [resolution, setResolution] = useState({ width: 1080, height: 2400 })
  const frameCountRef = useRef(0)
  const lastTimeRef = useRef(Date.now())

  // Initialize FPS counter
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now()
      const elapsed = (now - lastTimeRef.current) / 1000
      const currentFps = Math.round(frameCountRef.current / elapsed)
      setFps(currentFps)
      frameCountRef.current = 0
      lastTimeRef.current = now
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  const connectDevice = async () => {
    try {
      // Request USB device (Android phone via ADB)
      const device = await navigator.usb.requestDevice({
        filters: [{ classCode: 0xff }], // Android Debug Bridge
      })

      await device.open()
      setDevice(device)
      setConnected(true)

      // Simulate connection ping
      const start = Date.now()
      setPing(Date.now() - start)

      console.log("[v0] Device connected:", device.productName)
    } catch (error) {
      console.error("[v0] Failed to connect:", error)
      alert(
        "Không thể kết nối. Vui lòng:\n1. Bật USB Debugging trên điện thoại\n2. Cho phép kết nối USB khi được hỏi\n3. Thử lại",
      )
    }
  }

  const disconnectDevice = async () => {
    if (device) {
      await device.close()
      setDevice(null)
      setConnected(false)
    }
  }

  const sendCommand = async (command: string) => {
    if (!connected) {
      console.log("[v0] Not connected")
      return
    }

    const startTime = Date.now()

    // Simulate sending ADB command
    console.log(`[v0] Sending command: ${command}`)

    // Update ping
    setPing(Date.now() - startTime)

    // Simulate frame update
    frameCountRef.current++
  }

  const handleBack = () => sendCommand("input keyevent KEYCODE_BACK")
  const handleHome = () => sendCommand("input keyevent KEYCODE_HOME")
  const handleRecent = () => sendCommand("input keyevent KEYCODE_APP_SWITCH")
  const handleVolumeUp = () => sendCommand("input keyevent KEYCODE_VOLUME_UP")
  const handleVolumeDown = () => sendCommand("input keyevent KEYCODE_VOLUME_DOWN")

  // Canvas touch handling
  const handleCanvasTouch = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!connected) return

    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const scaleX = resolution.width / rect.width
    const scaleY = resolution.height / rect.height
    const x = Math.round((e.clientX - rect.left) * scaleX)
    const y = Math.round((e.clientY - rect.top) * scaleY)

    sendCommand(`input tap ${x} ${y}`)
  }

  return (
    <div className="mx-auto max-w-7xl">
      {/* Header */}
      <header className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-mono text-3xl font-bold glow-text">Phone Controller</h1>
            <p className="text-muted-foreground text-sm mt-1">Điều khiển điện thoại Android qua USB với độ trễ thấp</p>
          </div>

          <div className="flex gap-3">
            <Card className="px-4 py-2 bg-card/50 backdrop-blur">
              <div className="flex items-center gap-2 text-sm">
                <Activity className="h-4 w-4 text-primary" />
                <span className="font-mono font-semibold">{fps}</span>
                <span className="text-muted-foreground">FPS</span>
              </div>
            </Card>

            <Card className="px-4 py-2 bg-card/50 backdrop-blur">
              <div className="flex items-center gap-2 text-sm">
                <Wifi className="h-4 w-4 text-primary" />
                <span className="font-mono font-semibold">{ping}</span>
                <span className="text-muted-foreground">ms</span>
              </div>
            </Card>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="grid lg:grid-cols-[1fr_auto] gap-6">
        {/* Phone Display */}
        <Card className="p-6 bg-card/50 backdrop-blur">
          <div className="flex flex-col items-center">
            {!connected ? (
              <div className="flex flex-col items-center justify-center h-[600px] w-full max-w-[350px] border-2 border-dashed border-border rounded-lg">
                <Smartphone className="h-16 w-16 text-muted-foreground mb-4" />
                <p className="text-muted-foreground text-center mb-6">Chưa kết nối điện thoại</p>
                <Button onClick={connectDevice} size="lg" className="glow font-mono">
                  Kết nối điện thoại
                </Button>
              </div>
            ) : (
              <div className="relative">
                <canvas
                  ref={canvasRef}
                  width={resolution.width}
                  height={resolution.height}
                  onClick={handleCanvasTouch}
                  className="max-w-[350px] h-auto border-2 border-primary/50 rounded-lg cursor-crosshair glow"
                  style={{
                    backgroundColor: "#000",
                    aspectRatio: `${resolution.width}/${resolution.height}`,
                  }}
                />
                <div className="absolute top-2 right-2">
                  <div className="h-3 w-3 bg-primary rounded-full animate-pulse glow" />
                </div>
              </div>
            )}
          </div>
        </Card>

        {/* Controls */}
        <Card className="p-6 bg-card/50 backdrop-blur lg:w-80">
          <h2 className="font-mono text-xl font-semibold mb-4 glow-text">Điều khiển</h2>

          <div className="space-y-4">
            {/* Navigation Buttons */}
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground font-mono">Điều hướng</p>
              <div className="grid grid-cols-3 gap-2">
                <Button
                  onClick={handleBack}
                  disabled={!connected}
                  variant="outline"
                  size="lg"
                  className="font-mono bg-transparent"
                >
                  <ArrowLeft className="h-5 w-5" />
                </Button>
                <Button
                  onClick={handleHome}
                  disabled={!connected}
                  variant="outline"
                  size="lg"
                  className="font-mono bg-transparent"
                >
                  <Home className="h-5 w-5" />
                </Button>
                <Button
                  onClick={handleRecent}
                  disabled={!connected}
                  variant="outline"
                  size="lg"
                  className="font-mono bg-transparent"
                >
                  <Square className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Volume Controls */}
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground font-mono">Âm lượng</p>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  onClick={handleVolumeDown}
                  disabled={!connected}
                  variant="outline"
                  size="lg"
                  className="font-mono bg-transparent"
                >
                  <VolumeX className="h-5 w-5" />
                </Button>
                <Button
                  onClick={handleVolumeUp}
                  disabled={!connected}
                  variant="outline"
                  size="lg"
                  className="font-mono bg-transparent"
                >
                  <Volume2 className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Connection */}
            <div className="pt-4 border-t border-border">
              {connected ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground font-mono">Trạng thái</span>
                    <span className="text-primary font-mono font-semibold">Đã kết nối</span>
                  </div>
                  <Button onClick={disconnectDevice} variant="destructive" className="w-full font-mono">
                    Ngắt kết nối
                  </Button>
                </div>
              ) : (
                <div className="text-center text-sm text-muted-foreground font-mono">
                  Nhấn "Kết nối điện thoại" để bắt đầu
                </div>
              )}
            </div>

            {/* Instructions */}
            <Card className="p-4 bg-secondary/30">
              <h3 className="text-sm font-semibold font-mono mb-2 text-primary">Hướng dẫn</h3>
              <ul className="text-xs space-y-1 text-muted-foreground font-mono">
                <li>1. Bật USB Debugging</li>
                <li>2. Cắm USB vào PC</li>
                <li>3. Nhấn kết nối</li>
                <li>4. Chạm vào màn hình để điều khiển</li>
              </ul>
            </Card>
          </div>
        </Card>
      </div>
    </div>
  )
}
