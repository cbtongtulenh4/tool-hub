import PhoneController from "@/components/phone-controller"

export default function Page() {
  return (
    <main className="min-h-screen bg-background p-4">
      <PhoneController />
    </main>
  )
}
