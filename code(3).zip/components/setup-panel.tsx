"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { X, FolderOpen, Play, Square, RotateCcw, ChevronDown, Zap } from "lucide-react"

interface TestCase {
  id: string
  name: string
  status: "pending" | "running" | "passed" | "failed"
  duration?: number
}

const MOCK_TESTCASES: TestCase[] = [
  { id: "1", name: "test_login_flow.py", status: "passed", duration: 2340 },
  { id: "2", name: "test_checkout_process.py", status: "passed", duration: 3120 },
  { id: "3", name: "test_user_registration.py", status: "running", duration: 1240 },
  { id: "4", name: "test_search_functionality.py", status: "pending" },
  { id: "5", name: "test_payment_integration.py", status: "pending" },
  { id: "6", name: "test_profile_settings.py", status: "pending" },
]

export default function SetupPanel() {
  const [projectPath, setProjectPath] = useState("/home/user/test-project")
  const [selectedDevice, setSelectedDevice] = useState("Pixel_6_Pro_API_33")
  const [isRunning, setIsRunning] = useState(true)
  const [testCases, setTestCases] = useState<TestCase[]>(MOCK_TESTCASES)
  const [showDetailsModal, setShowDetailsModal] = useState(false)
  const [buttonStates, setButtonStates] = useState<Record<string, boolean>>({
    run: false,
    stop: true,
    refresh: false,
  })

  const devices = ["Pixel_6_Pro_API_33", "Samsung_Galaxy_S21", "OnePlus_9", "Xiaomi_12"]

  const runningTestCase = testCases.find((tc) => tc.status === "running")
  const passedCount = testCases.filter((tc) => tc.status === "passed").length
  const failedCount = testCases.filter((tc) => tc.status === "failed").length
  const totalTests = testCases.length

  const handleRun = () => {
    setIsRunning(true)
    setButtonStates({ run: true, stop: false, refresh: false })
    setTimeout(() => setButtonStates({ run: false, stop: true, refresh: true }), 800)
  }

  const handleStop = () => {
    setIsRunning(false)
    setButtonStates({ run: false, stop: true, refresh: true })
    setTestCases((prev) => prev.map((tc) => (tc.status === "running" ? { ...tc, status: "pending" } : tc)))
  }

  const handleRefresh = () => {
    setButtonStates((prev) => ({ ...prev, refresh: true }))
    setTimeout(() => setButtonStates((prev) => ({ ...prev, refresh: false })), 600)
  }

  return (
    <>
      {/* Compact Setup Header */}
      <div className="border-b border-slate-200/50 dark:border-slate-800/50 bg-slate-50/50 dark:bg-slate-900/20 backdrop-blur-sm px-6 py-4">
        <div className="flex items-center justify-between gap-6">
          {/* Left: Project & Device - Minimal Display */}
          <div className="flex items-center gap-4 flex-1 min-w-0">
            <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-white dark:bg-slate-800/40 border border-slate-200/50 dark:border-slate-700/50 hover:border-slate-300 dark:hover:border-slate-600 transition-colors">
              <FolderOpen className="w-4 h-4 text-slate-500 dark:text-slate-400 flex-shrink-0" />
              <span className="text-sm font-medium text-slate-700 dark:text-slate-200 truncate max-w-[200px]">
                {projectPath.split("/").pop()}
              </span>
            </div>

            <div className="w-px h-5 bg-slate-200/50 dark:bg-slate-700/50" />

            <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-white dark:bg-slate-800/40 border border-slate-200/50 dark:border-slate-700/50 hover:border-slate-300 dark:hover:border-slate-600 transition-colors">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-sm font-medium text-slate-700 dark:text-slate-200">{selectedDevice}</span>
              <ChevronDown className="w-3 h-3 text-slate-500 dark:text-slate-400" />
            </div>
          </div>

          {/* Center: Status Badge */}
          {runningTestCase && (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-cyan-500/10 to-blue-500/10 dark:from-cyan-500/20 dark:to-blue-500/20 border border-cyan-200/50 dark:border-cyan-700/50">
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse" />
              <span className="text-xs font-medium text-cyan-700 dark:text-cyan-300">Running</span>
            </div>
          )}

          {/* Right: Stats */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3 px-3 py-2 rounded-lg bg-white dark:bg-slate-800/40 border border-slate-200/50 dark:border-slate-700/50">
              <div className="text-center">
                <p className="text-xs text-slate-500 dark:text-slate-400">Passed</p>
                <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">{passedCount}</p>
              </div>
              <div className="w-px h-6 bg-slate-200/50 dark:bg-slate-700/50" />
              <div className="text-center">
                <p className="text-xs text-slate-500 dark:text-slate-400">Failed</p>
                <p className="text-sm font-bold text-red-600 dark:text-red-400">{failedCount}</p>
              </div>
            </div>

            <div className="flex gap-2 bg-white dark:bg-slate-800/40 border border-slate-200/50 dark:border-slate-700/50 rounded-lg p-1">
              <Button
                size="sm"
                onClick={handleRun}
                disabled={isRunning}
                className={`h-7 px-3 text-xs font-medium transition-all duration-200 ${
                  isRunning
                    ? "bg-slate-100 dark:bg-slate-700 text-slate-400 dark:text-slate-500 cursor-not-allowed"
                    : "bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white shadow-sm hover:shadow-md hover:scale-105 active:scale-95"
                }`}
              >
                <Play className="w-3 h-3 mr-1.5" />
                Run
              </Button>
              <Button
                size="sm"
                onClick={handleStop}
                disabled={!isRunning}
                className={`h-7 px-3 text-xs font-medium transition-all duration-200 ${
                  !isRunning
                    ? "bg-slate-100 dark:bg-slate-700 text-slate-400 dark:text-slate-500 cursor-not-allowed"
                    : "bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white shadow-sm hover:shadow-md hover:scale-105 active:scale-95"
                }`}
              >
                <Square className="w-3 h-3 mr-1.5" />
                Stop
              </Button>
              <Button
                size="sm"
                onClick={handleRefresh}
                disabled={buttonStates.refresh}
                className={`h-7 px-3 text-xs font-medium transition-all duration-200 ${
                  buttonStates.refresh
                    ? "bg-slate-100 dark:bg-slate-700 text-slate-400 dark:text-slate-500"
                    : "bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600 hover:scale-105 active:scale-95"
                }`}
              >
                <RotateCcw className={`w-3 h-3 ${buttonStates.refresh ? "animate-spin" : ""}`} />
              </Button>
              <div className="w-px bg-slate-200/50 dark:bg-slate-600/50" />
              <Button
                size="sm"
                onClick={() => setShowDetailsModal(true)}
                className="h-7 px-3 text-xs font-medium bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600 hover:scale-105 active:scale-95 transition-all duration-200"
              >
                <Zap className="w-3 h-3 mr-1" />
                Details
              </Button>
            </div>
          </div>
        </div>
      </div>

      {showDetailsModal && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 transition-opacity duration-300"
            onClick={() => setShowDetailsModal(false)}
          />

          {/* Modal */}
          <div className="fixed inset-0 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200/50 dark:border-slate-800 w-full max-w-3xl max-h-[80vh] overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-300">
              {/* Modal Header */}
              <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200/50 dark:border-slate-800 bg-gradient-to-r from-slate-50 to-white dark:from-slate-800/50 dark:to-slate-900/50">
                <div>
                  <h2 className="text-lg font-semibold text-slate-900 dark:text-white">Configuration Details</h2>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                    Manage project and device settings
                  </p>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setShowDetailsModal(false)}
                  className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 p-1 h-auto"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* Modal Content */}
              <div className="overflow-y-auto flex-1 p-6 space-y-6">
                {/* Project Path */}
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-900 dark:text-white">Project Path</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={projectPath}
                      readOnly
                      className="flex-1 px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-300 font-mono"
                    />
                    <Button className="bg-cyan-600 hover:bg-cyan-700 text-white px-4 h-auto py-2 text-sm font-medium rounded-lg transition-all duration-200 hover:scale-105 active:scale-95">
                      <FolderOpen className="w-4 h-4 mr-2" />
                      Browse
                    </Button>
                  </div>
                </div>

                {/* Device Selection */}
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-900 dark:text-white">Select Device</label>
                  <select
                    value={selectedDevice}
                    onChange={(e) => setSelectedDevice(e.target.value)}
                    className="w-full px-3 py-2.5 text-sm bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 font-medium focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all duration-200"
                  >
                    {devices.map((device) => (
                      <option key={device} value={device}>
                        {device}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Test Summary Grid */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="p-4 rounded-lg bg-gradient-to-br from-slate-50 to-white dark:from-slate-800/50 dark:to-slate-800/30 border border-slate-200/50 dark:border-slate-700/50">
                    <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      Total Tests
                    </p>
                    <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">{totalTests}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-gradient-to-br from-emerald-50 to-emerald-50/50 dark:from-emerald-900/20 dark:to-emerald-900/10 border border-emerald-200/50 dark:border-emerald-800/50">
                    <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider">
                      Passed
                    </p>
                    <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">{passedCount}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-gradient-to-br from-red-50 to-red-50/50 dark:from-red-900/20 dark:to-red-900/10 border border-red-200/50 dark:border-red-800/50">
                    <p className="text-xs font-semibold text-red-700 dark:text-red-400 uppercase tracking-wider">
                      Failed
                    </p>
                    <p className="text-2xl font-bold text-red-600 dark:text-red-400 mt-1">{failedCount}</p>
                  </div>
                </div>

                {/* Test Cases List */}
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-900 dark:text-white">Test Cases</label>
                  <div className="bg-slate-50 dark:bg-slate-800/30 border border-slate-200 dark:border-slate-700 rounded-lg p-3 max-h-60 overflow-y-auto space-y-2">
                    {testCases.map((tc) => (
                      <div
                        key={tc.id}
                        className="flex items-center gap-3 p-2.5 rounded-lg bg-white dark:bg-slate-800/50 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors border border-slate-200/50 dark:border-slate-700/50"
                      >
                        <div
                          className={`w-2 h-2 rounded-full flex-shrink-0 ${
                            tc.status === "passed"
                              ? "bg-emerald-500"
                              : tc.status === "failed"
                                ? "bg-red-500"
                                : tc.status === "running"
                                  ? "bg-cyan-500 animate-pulse"
                                  : "bg-slate-300 dark:bg-slate-600"
                          }`}
                        />
                        <span className="flex-1 text-sm font-medium text-slate-700 dark:text-slate-300 font-mono">
                          {tc.name}
                        </span>
                        {tc.duration && (
                          <span className="text-xs text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded">
                            {(tc.duration / 1000).toFixed(1)}s
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="px-6 py-4 border-t border-slate-200/50 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex gap-3 justify-end">
                <Button
                  variant="outline"
                  onClick={() => setShowDetailsModal(false)}
                  className="text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Close
                </Button>
                <Button className="bg-cyan-600 hover:bg-cyan-700 text-white font-medium transition-all duration-200 hover:scale-105 active:scale-95">
                  Save Changes
                </Button>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  )
}
