"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Smartphone } from "lucide-react"

export default function DevicePreview() {
  return (
    <Card className="w-[30%] bg-slate-900 border-slate-700 flex flex-col dark:bg-slate-900/50">
      <CardHeader className="pb-3 flex-shrink-0 border-b border-slate-700">
        <CardTitle className="text-sm flex items-center gap-2 text-slate-200">
          <Smartphone className="w-4 h-4" />
          Device View
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 flex items-center justify-center p-4 overflow-hidden">
        {/* Phone Frame */}
        <div className="relative w-full h-full max-h-96 max-w-48 rounded-3xl bg-slate-950 border-8 border-slate-800 shadow-2xl overflow-hidden flex items-center justify-center">
          {/* Phone Screen */}
          <div className="absolute inset-2 bg-gradient-to-br from-blue-900 via-slate-800 to-slate-900 rounded-2xl flex flex-col items-center justify-center overflow-hidden">
            {/* Status Bar */}
            <div className="w-full h-6 bg-slate-950 flex items-center justify-between px-3 text-xs text-slate-400">
              <span>9:41</span>
              <div className="flex gap-1">
                <span>📶</span>
                <span>🔋</span>
              </div>
            </div>

            {/* Screen Content */}
            <div className="flex-1 w-full flex flex-col items-center justify-center px-4 space-y-4">
              <div className="w-12 h-12 rounded-full bg-cyan-500/30 animate-pulse" />
              <div className="text-center space-y-2">
                <div className="h-3 w-24 bg-slate-700 rounded-full mx-auto" />
                <div className="h-2 w-32 bg-slate-700 rounded-full mx-auto" />
              </div>

              {/* Mock UI Elements */}
              <div className="w-full space-y-3 mt-8">
                <div className="h-8 bg-slate-700/50 rounded-lg" />
                <div className="h-8 bg-slate-700/50 rounded-lg" />
                <div className="h-8 bg-cyan-500/20 rounded-lg border border-cyan-500/40" />
              </div>

              {/* Live Indicator */}
              <div className="mt-auto mb-4 flex items-center gap-1.5 text-xs text-cyan-400">
                <span className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
                <span>Live</span>
              </div>
            </div>
          </div>

          {/* Phone Notch */}
          <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-24 h-7 bg-slate-950 rounded-b-3xl border-l-8 border-r-8 border-slate-800" />
        </div>
      </CardContent>
    </Card>
  )
}
