"use client"
import Header from "@/components/header"
import SetupPanel from "@/components/setup-panel"
import LogViewer from "@/components/log-viewer"
import DevicePreview from "@/components/device-preview"

export default function Home() {
  return (
    <main className="flex flex-col h-screen bg-background text-foreground dark:bg-slate-950 dark:text-slate-50">
      <Header />

      <div className="flex-1 flex flex-col overflow-hidden">
        <SetupPanel />

        <div className="flex-1 flex gap-4 overflow-hidden p-4">
          <LogViewer />
          <DevicePreview />
        </div>
      </div>
    </main>
  )
}
