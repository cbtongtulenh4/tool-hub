"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Download, Copy } from "lucide-react"
import { Button } from "@/components/ui/button"
import StreamingLogLine from "./streaming-log-line"

const MOCK_LOGS = [
  { text: "[14:35:22] Starting test suite initialization...", type: "info" },
  { text: "[14:35:23] Connecting to uiautomator2 server", type: "info" },
  { text: "[14:35:24] Device: Pixel_6_Pro_API_33 connected successfully", type: "success" },
  { text: "[14:35:25] Loading test configuration from /tests/config.yaml", type: "info" },
  { text: "[14:35:26] Found 5 test cases to execute", type: "info" },
  { text: "", type: "info" }, // blank line for spacing
  { text: "[14:35:27] ▶ Executing: test_login_flow.py", type: "info" },
  { text: "[14:35:28] → Opening application com.example.app", type: "info" },
  { text: "[14:35:29] → Waiting for login screen (timeout: 10s)", type: "info" },
  { text: "[14:35:30] → Found login button at xpath: //*[@id='login_btn']", type: "info" },
  { text: "[14:35:31] → Entering email: test@example.com", type: "info" },
  { text: "[14:35:32] → Entering password: ••••••••", type: "info" },
  { text: "[14:35:33] → Tapping login button", type: "info" },
  { text: "[14:35:34] ✓ test_login_flow.py PASSED (2.34s)", type: "success" },
  { text: "", type: "info" },
  { text: "[14:35:35] ▶ Executing: test_checkout_process.py", type: "info" },
  { text: "[14:35:36] → Navigating to products page", type: "info" },
  { text: "[14:35:37] → Selecting product: Premium Plan", type: "info" },
  { text: "[14:35:38] → Adding item to cart", type: "info" },
  { text: "[14:35:39] → Proceeding to checkout", type: "info" },
  { text: "[14:35:40] ⚠ Self-healing: Element selector changed", type: "healing" },
  {
    text: "[14:35:41] 🔧 Self-healing: Attempting to locate element with fallback strategies...",
    type: "healing",
  },
  {
    text: "[14:35:42] 🔧 Self-healing: Found new selector via image matching (confidence: 0.94)",
    type: "healing",
  },
  { text: "[14:35:43] 🔧 Self-healing: Applied new xpath: //*[contains(@text, 'Confirm')]", type: "healing" },
  { text: "[14:35:44] → Confirming purchase with updated selector", type: "info" },
  { text: "[14:35:45] → Processing payment", type: "info" },
  { text: "[14:35:46] ✓ test_checkout_process.py PASSED (3.12s)", type: "success" },
  { text: "", type: "info" },
  { text: "[14:35:47] ▶ Executing: test_user_registration.py", type: "info" },
  { text: "[14:35:48] → Opening registration form", type: "info" },
  { text: "[14:35:49] ⚠ Self-healing: UI element layout changed detected", type: "healing" },
  { text: "[14:35:50] 🔧 Self-healing: Analyzing screenshot and retrying with ML model...", type: "healing" },
  { text: "[14:35:51] 🔧 Self-healing: Located element using computer vision (accuracy: 0.91)", type: "healing" },
  { text: "[14:35:52] → Filling user details with recovered selectors", type: "info" },
  { text: "[14:35:53] → Submitting registration", type: "info" },
  { text: "[14:35:54] → Waiting for confirmation email", type: "info" },
  { text: "[14:35:55] ✓ test_user_registration.py PASSED (2.89s)", type: "success" },
  { text: "", type: "info" },
  { text: "[14:35:56] ════════════════════════════════════════", type: "info" },
  { text: "[14:35:57] Test Suite Summary:", type: "info" },
  { text: "[14:35:58] Total Tests: 5", type: "info" },
  { text: "[14:35:59] ✓ Passed: 3", type: "success" },
  { text: "[14:36:00] Self-healing Events: 2", type: "healing" },
  { text: "[14:36:01] Duration: 38.2s", type: "info" },
  { text: "[14:36:02] ════════════════════════════════════════", type: "info" },
]

export default function LogViewer() {
  const [displayedLogs, setDisplayedLogs] = useState<typeof MOCK_LOGS>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const scrollRef = useRef<HTMLDivElement>(null)
  const [isRunning, setIsRunning] = useState(true)

  useEffect(() => {
    if (!isRunning || currentIndex >= MOCK_LOGS.length) {
      if (currentIndex >= MOCK_LOGS.length) {
        setIsRunning(false)
      }
      return
    }

    // Add delay between log lines for more natural streaming effect
    const timer = setTimeout(() => {
      setDisplayedLogs((prev) => [...prev, MOCK_LOGS[currentIndex]])
      setCurrentIndex((prev) => prev + 1)
    }, 800) // 800ms between log lines

    return () => clearTimeout(timer)
  }, [currentIndex, isRunning])

  // Auto-scroll to bottom when new logs arrive
  useEffect(() => {
    if (scrollRef.current) {
      setTimeout(() => {
        scrollRef.current!.scrollTop = scrollRef.current!.scrollHeight
      }, 0)
    }
  }, [displayedLogs])

  const getLogType = (log: (typeof MOCK_LOGS)[0]) => ({
    isError: log.type === "error",
    isSuccess: log.type === "success",
    isHealing: log.type === "healing",
  })

  return (
    <Card className="flex-1 bg-slate-900 border-slate-700 flex flex-col dark:bg-slate-900/50">
      <CardHeader className="pb-3 flex-shrink-0 border-b border-slate-700">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CardTitle className="text-sm text-slate-200">Console Log</CardTitle>
            {isRunning && <span className="inline-block w-2 h-2 bg-green-400 rounded-full animate-pulse" />}
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-slate-400 hover:text-slate-300">
              <Copy className="w-3 h-3" />
            </Button>
            <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-slate-400 hover:text-slate-300">
              <Download className="w-3 h-3" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1 overflow-hidden p-0">
        <div
          ref={scrollRef}
          className="h-full overflow-y-auto font-mono text-xs bg-slate-950 text-slate-300 p-4 space-y-1 custom-scrollbar"
        >
          {displayedLogs.map((log, idx) => (
            <StreamingLogLine key={idx} text={log.text} {...getLogType(log)} />
          ))}
        </div>
      </CardContent>
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(15, 23, 42, 0.5);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(71, 85, 105, 0.5);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(71, 85, 105, 0.8);
        }
      `}</style>
    </Card>
  )
}
