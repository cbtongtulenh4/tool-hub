"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { FolderOpen, Play, Square, RotateCcw, Loader2, Info } from "lucide-react"

interface TestCase {
  id: string
  name: string
  status: "pending" | "running" | "passed" | "failed"
  duration?: number
}

const MOCK_TESTCASES: TestCase[] = [
  { id: "1", name: "test_login_flow.py", status: "passed", duration: 2340 },
  { id: "2", name: "test_checkout_process.py", status: "passed", duration: 3120 },
  { id: "3", name: "test_user_registration.py", status: "running", duration: 1240 },
  { id: "4", name: "test_search_functionality.py", status: "pending" },
  { id: "5", name: "test_payment_integration.py", status: "pending" },
  { id: "6", name: "test_profile_settings.py", status: "pending" },
]

export default function SetupPanel() {
  const [projectPath, setProjectPath] = useState("/home/user/test-project")
  const [selectedDevice, setSelectedDevice] = useState("Pixel_6_Pro_API_33")
  const [isRunning, setIsRunning] = useState(true)
  const [testCases, setTestCases] = useState<TestCase[]>(MOCK_TESTCASES)
  const [showDetails, setShowDetails] = useState(false)
  const [showTestCases, setShowTestCases] = useState(false)

  const devices = ["Pixel_6_Pro_API_33", "Samsung_Galaxy_S21", "OnePlus_9", "Xiaomi_12"]

  const runningTestCase = testCases.find((tc) => tc.status === "running")
  const passedCount = testCases.filter((tc) => tc.status === "passed").length
  const failedCount = testCases.filter((tc) => tc.status === "failed").length
  const totalTests = testCases.length

  const handleStop = () => {
    setIsRunning(false)
    setTestCases((prev) => prev.map((tc) => (tc.status === "running" ? { ...tc, status: "pending" } : tc)))
  }

  const handleRun = () => {
    setIsRunning(true)
  }

  return (
    <>
      <div className="border-b border-slate-200 dark:border-slate-800 bg-gradient-to-r from-slate-50 to-white dark:from-slate-900 dark:to-slate-950 px-6 py-3">
        <div className="flex items-center justify-between gap-6">
          {/* Left: Project & Device Info */}
          <div className="flex items-center gap-8 flex-1">
            <div className="flex items-center gap-2 min-w-0">
              <FolderOpen className="w-4 h-4 text-slate-500 dark:text-slate-400 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-xs text-slate-500 dark:text-slate-400">Project</p>
                <p className="text-sm font-medium text-slate-700 dark:text-slate-200 truncate">
                  {projectPath.split("/").pop()}
                </p>
              </div>
              <Button size="sm" variant="ghost" className="text-xs h-6 px-2 ml-2">
                Change
              </Button>
            </div>

            <div className="h-8 w-px bg-slate-200 dark:bg-slate-800" />

            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-emerald-500" />
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">Device</p>
                <p className="text-sm font-medium text-slate-700 dark:text-slate-200">{selectedDevice}</p>
              </div>
              <Button size="sm" variant="ghost" className="text-xs h-6 px-2 ml-2">
                Select
              </Button>
            </div>
          </div>

          {/* Center: Progress */}
          <div className="flex items-center gap-4">
            {runningTestCase && (
              <div className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 text-cyan-500 animate-spin flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs text-slate-500 dark:text-slate-400">Running</p>
                  <p className="text-sm font-medium text-slate-700 dark:text-slate-200 truncate max-w-[200px]">
                    {runningTestCase.name}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Right: Stats & Actions */}
          <div className="flex items-center gap-4">
            <div className="flex gap-1">
              <div className="text-center">
                <p className="text-xs text-slate-500 dark:text-slate-400">Passed</p>
                <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-400">{passedCount}</p>
              </div>
              <div className="w-px bg-slate-200 dark:bg-slate-800" />
              <div className="text-center">
                <p className="text-xs text-slate-500 dark:text-slate-400">Failed</p>
                <p className="text-sm font-semibold text-red-600 dark:text-red-400">{failedCount}</p>
              </div>
            </div>

            <div className="h-6 w-px bg-slate-200 dark:bg-slate-800" />

            <div className="flex gap-2">
              <Button
                size="sm"
                onClick={handleRun}
                disabled={isRunning}
                className="h-8 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs"
              >
                <Play className="w-3.5 h-3.5 mr-1" />
                Run
              </Button>
              <Button
                size="sm"
                onClick={handleStop}
                disabled={!isRunning}
                className="h-8 px-3 bg-red-600 hover:bg-red-700 text-white text-xs"
              >
                <Square className="w-3.5 h-3.5 mr-1" />
                Stop
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="h-8 px-3 text-xs border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 bg-transparent"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setShowDetails(!showDetails)}
                className="h-8 px-2 text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100"
              >
                <Info className="w-3.5 h-3.5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {showDetails && (
        <div className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/30 px-6 py-4">
          <div className="max-w-7xl mx-auto space-y-4">
            <div className="grid grid-cols-3 gap-6">
              {/* Project Details */}
              <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
                <CardContent className="pt-4 space-y-3">
                  <div>
                    <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase">Project Path</p>
                    <p className="text-sm text-slate-700 dark:text-slate-300 font-mono mt-1 break-all">{projectPath}</p>
                    <Button size="sm" variant="outline" className="mt-2 h-7 text-xs bg-transparent">
                      <FolderOpen className="w-3 h-3 mr-1" />
                      Browse
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Device Selection */}
              <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
                <CardContent className="pt-4">
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase mb-2">Select Device</p>
                  <select
                    value={selectedDevice}
                    onChange={(e) => setSelectedDevice(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  >
                    {devices.map((device) => (
                      <option key={device} value={device}>
                        {device}
                      </option>
                    ))}
                  </select>
                </CardContent>
              </Card>

              {/* Test Summary */}
              <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
                <CardContent className="pt-4 space-y-2">
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase mb-3">Summary</p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600 dark:text-slate-400">Total</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-200">{totalTests}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600 dark:text-slate-400">Passed</span>
                      <span className="font-semibold text-emerald-600 dark:text-emerald-400">{passedCount}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600 dark:text-slate-400">Failed</span>
                      <span className="font-semibold text-red-600 dark:text-red-400">{failedCount}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Test Cases List */}
            <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
              <CardContent className="pt-4">
                <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase mb-3">Test Cases</p>
                <div className="max-h-64 overflow-y-auto space-y-2">
                  {testCases.map((tc) => (
                    <div key={tc.id} className="flex items-center gap-3 p-2.5 rounded bg-slate-50 dark:bg-slate-900/50">
                      <div
                        className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${
                          tc.status === "passed"
                            ? "bg-emerald-500"
                            : tc.status === "failed"
                              ? "bg-red-500"
                              : tc.status === "running"
                                ? "bg-cyan-500 animate-pulse"
                                : "bg-slate-300 dark:bg-slate-600"
                        }`}
                      />
                      <span className="flex-1 text-sm text-slate-700 dark:text-slate-300">{tc.name}</span>
                      {tc.duration && (
                        <span className="text-xs text-slate-500 dark:text-slate-400">
                          {(tc.duration / 1000).toFixed(1)}s
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </>
  )
}
