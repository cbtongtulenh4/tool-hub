"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Download, Copy } from "lucide-react"
import { Button } from "@/components/ui/button"

const MOCK_LOGS = [
  "[2025-11-13 14:35:22] Starting test suite...",
  "[2025-11-13 14:35:23] Initializing uiautomator2 connection",
  "[2025-11-13 14:35:24] Device: Pixel_6_Pro_API_33 connected",
  "[2025-11-13 14:35:25] Running test_login_flow.py",
  "[2025-11-13 14:35:26] -> Opening application",
  "[2025-11-13 14:35:27] -> Waiting for login screen",
  "[2025-11-13 14:35:28] -> Entering credentials",
  "[2025-11-13 14:35:30] -> Tapping login button",
  "[2025-11-13 14:35:32] ✓ test_login_flow.py PASSED (2.34s)",
  "[2025-11-13 14:35:33] Running test_checkout_process.py",
  "[2025-11-13 14:35:34] -> Navigating to products",
  "[2025-11-13 14:35:35] -> Adding item to cart",
  "[2025-11-13 14:35:37] -> Proceeding to checkout",
  "[2025-11-13 14:35:39] -> Self-healing: Found changed element selector",
  "[2025-11-13 14:35:40] -> Self-healing: Applied new selector (xpath=\"//*[@id='pay-btn']\")",
  "[2025-11-13 14:35:42] -> Confirming purchase",
  "[2025-11-13 14:35:45] ✓ test_checkout_process.py PASSED (3.12s)",
  "[2025-11-13 14:35:46] Running test_user_registration.py",
  "[2025-11-13 14:35:47] -> Opening registration form",
  "[2025-11-13 14:35:48] -> Filling user details",
  "[2025-11-13 14:35:49] -> Self-healing: Retrying with fallback locator",
  "[2025-11-13 14:35:50] -> Submitting registration",
  "[2025-11-13 14:35:52] -> Waiting for confirmation email",
]

export default function LogViewer() {
  const [logs, setLogs] = useState<string[]>(MOCK_LOGS)
  const scrollRef = useRef<HTMLDivElement>(null)

  // Auto-scroll to bottom when new logs arrive
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [logs])

  // Simulate incoming logs
  useEffect(() => {
    const interval = setInterval(() => {
      const newLog = `[${new Date().toLocaleTimeString()}] Executing test step...`
      setLogs((prev) => [...prev, newLog].slice(-100)) // Keep last 100 logs
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  return (
    <Card className="flex-1 bg-slate-900 border-slate-700 flex flex-col dark:bg-slate-900/50">
      <CardHeader className="pb-3 flex-shrink-0 border-b border-slate-700">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm text-slate-200">Console Log</CardTitle>
          <div className="flex gap-2">
            <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-slate-400 hover:text-slate-300">
              <Copy className="w-3 h-3" />
            </Button>
            <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-slate-400 hover:text-slate-300">
              <Download className="w-3 h-3" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1 overflow-hidden p-0">
        <div
          ref={scrollRef}
          className="h-full overflow-y-auto font-mono text-xs bg-slate-950 text-slate-300 p-4 space-y-1 custom-scrollbar"
        >
          {logs.map((log, idx) => {
            const isError = log.includes("ERROR") || log.includes("FAILED")
            const isSuccess = log.includes("✓") || log.includes("PASSED")
            const isHealing = log.includes("Self-healing")

            return (
              <div
                key={idx}
                className={`font-mono text-xs leading-relaxed whitespace-pre-wrap break-words ${
                  isError
                    ? "text-red-400"
                    : isSuccess
                      ? "text-green-400"
                      : isHealing
                        ? "text-amber-400"
                        : "text-slate-400"
                }`}
              >
                {log}
              </div>
            )
          })}
        </div>
      </CardContent>
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(15, 23, 42, 0.5);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(71, 85, 105, 0.5);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(71, 85, 105, 0.8);
        }
      `}</style>
    </Card>
  )
}
