import { useEffect, useRef, useState } from "react"

interface DeviceSocketHooks {
  isConnected: boolean
  isConnecting: boolean
  error: string | null
  sessionId: string | null
  connect: (deviceId: string) => Promise<void>
  disconnect: () => void
}

export function useDeviceSocket(
  canvasRef: React.RefObject<HTMLCanvasElement>
): DeviceSocketHooks {
  const [isConnected, setIsConnected] = useState(false)
  const [isConnecting, setIsConnecting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [sessionId, setSessionId] = useState<string | null>(null)
  const socketRef = useRef<WebSocket | null>(null)
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>()

  const connect = async (deviceId: string) => {
    setIsConnecting(true)
    setError(null)

    try {
      // Call API to initiate connection and get session ID
      const response = await fetch("/api/device/connect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ deviceId }),
      })

      if (!response.ok) {
        throw new Error(`Connection failed: ${response.statusText}`)
      }

      const data = await response.json()
      const newSessionId = data.sessionId
      setSessionId(newSessionId)

      // Connect to WebSocket
      const wsProtocol = window.location.protocol === "https:" ? "wss:" : "ws:"
      const wsUrl = `${wsProtocol}//${window.location.host}/api/device/stream?sessionId=${newSessionId}`

      const ws = new WebSocket(wsUrl)

      ws.onopen = () => {
        console.log("[v0] WebSocket connected for device streaming")
        setIsConnected(true)
        setIsConnecting(false)
      }

      ws.onmessage = (event) => {
        // Handle binary image data from device
        if (event.data instanceof Blob) {
          const reader = new FileReader()
          reader.onload = (e) => {
            const arrayBuffer = e.target?.result as ArrayBuffer
            const uint8Array = new Uint8Array(arrayBuffer)
            const imageData = new ImageData(uint8Array, 540, 960)

            if (canvasRef.current) {
              const ctx = canvasRef.current.getContext("2d")
              if (ctx) {
                ctx.putImageData(imageData, 0, 0)
              }
            }
          }
          reader.readAsArrayBuffer(event.data)
        }
      }

      ws.onerror = (event) => {
        console.error("[v0] WebSocket error:", event)
        setError("Connection error occurred")
        setIsConnected(false)
        setIsConnecting(false)
      }

      ws.onclose = () => {
        console.log("[v0] WebSocket disconnected")
        setIsConnected(false)
        // Attempt reconnect after 3 seconds
        reconnectTimeoutRef.current = setTimeout(() => {
          if (sessionId) connect(deviceId)
        }, 3000)
      }

      socketRef.current = ws
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Connection failed"
      setError(errorMessage)
      setIsConnecting(false)
      console.error("[v0] Connection error:", err)
    }
  }

  const disconnect = () => {
    if (socketRef.current) {
      socketRef.current.close()
      socketRef.current = null
    }
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current)
    }
    setIsConnected(false)
    setSessionId(null)
    setError(null)
  }

  useEffect(() => {
    return () => {
      if (socketRef.current) {
        socketRef.current.close()
      }
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current)
      }
    }
  }, [])

  return {
    isConnected,
    isConnecting,
    error,
    sessionId,
    connect,
    disconnect,
  }
}
