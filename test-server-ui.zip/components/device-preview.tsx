"use client"

import { useRef, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Smartphone, Wifi, WifiOff, AlertCircle, Loader } from 'lucide-react'
import { useDeviceSocket } from "@/hooks/use-device-socket"

export default function DevicePreview() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [selectedDevice, setSelectedDevice] = useState("device-1")
  const { isConnected, isConnecting, error, sessionId, connect, disconnect } = useDeviceSocket(canvasRef)

  const handleConnect = async () => {
    if (isConnected) {
      disconnect()
    } else {
      await connect(selectedDevice)
    }
  }

  return (
    <Card className="w-[30%] bg-slate-900 border-slate-700 flex flex-col dark:bg-slate-900/50">
      <CardHeader className="pb-3 flex-shrink-0 border-b border-slate-700 flex items-center justify-between">
        <CardTitle className="text-sm flex items-center gap-2 text-slate-200">
          <Smartphone className="w-4 h-4" />
          Device View
        </CardTitle>
        
        {/* Connection Status Badge */}
        <div className="flex items-center gap-2">
          {isConnected ? (
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-500/20 border border-emerald-500/40 rounded-md">
              <Wifi className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-xs font-medium text-emerald-300">Connected</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-700/50 border border-slate-600 rounded-md">
              <WifiOff className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-xs font-medium text-slate-300">Disconnected</span>
            </div>
          )}
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col items-center justify-center p-4 overflow-hidden gap-4">
        {/* Device Selection & Connect Button */}
        {!isConnected && !isConnecting && (
          <div className="w-full flex flex-col gap-3">
            <select
              value={selectedDevice}
              onChange={(e) => setSelectedDevice(e.target.value)}
              className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
            >
              <option value="device-1">Device 1 (192.168.1.100)</option>
              <option value="device-2">Device 2 (192.168.1.101)</option>
              <option value="device-3">Device 3 (192.168.1.102)</option>
            </select>

            <button
              onClick={handleConnect}
              className="w-full px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-500 text-white text-sm font-medium rounded-lg hover:from-cyan-600 hover:to-blue-600 transition-all duration-200 active:scale-95 shadow-lg hover:shadow-cyan-500/30"
            >
              Connect Device
            </button>
          </div>
        )}

        {/* Loading State */}
        {isConnecting && (
          <div className="flex flex-col items-center justify-center gap-3 py-8">
            <Loader className="w-8 h-8 text-cyan-400 animate-spin" />
            <div className="text-center space-y-1">
              <p className="text-xs font-medium text-slate-200">Connecting to device...</p>
              <p className="text-xs text-slate-400">Establishing socket connection</p>
            </div>
          </div>
        )}

        {/* Error State */}
        {error && !isConnecting && (
          <div className="w-full flex flex-col gap-3">
            <div className="w-full flex gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-xs font-medium text-red-300">Connection Error</p>
                <p className="text-xs text-red-200/70 mt-0.5">{error}</p>
              </div>
            </div>
            <button
              onClick={handleConnect}
              className="w-full px-4 py-2 bg-slate-800 border border-slate-700 text-slate-200 text-sm font-medium rounded-lg hover:bg-slate-700 transition-colors"
            >
              Retry Connection
            </button>
          </div>
        )}

        {/* Live Canvas - Shows Device Screen */}
        {isConnected && (
          <div className="relative w-full h-full max-h-96 max-w-48 rounded-3xl bg-slate-950 border-8 border-slate-800 shadow-2xl overflow-hidden flex items-center justify-center">
            {/* Phone Frame */}
            <canvas
              ref={canvasRef}
              width={540}
              height={960}
              className="absolute inset-2 rounded-2xl bg-slate-900"
            />

            {/* Phone Notch */}
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-24 h-7 bg-slate-950 rounded-b-3xl border-l-8 border-r-8 border-slate-800 z-10" />

            {/* Live Indicator */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex items-center gap-1.5 text-xs text-cyan-400 bg-slate-950/80 px-3 py-1.5 rounded-full z-10 backdrop-blur-sm">
              <span className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
              <span>Live ({sessionId?.substring(0, 8)}...)</span>
            </div>

            {/* Disconnect Button */}
            <button
              onClick={handleConnect}
              className="absolute top-4 right-4 px-3 py-1.5 bg-red-500/20 border border-red-500/40 text-red-300 text-xs font-medium rounded-lg hover:bg-red-500/30 transition-colors z-10"
            >
              Disconnect
            </button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
