import { Activity } from "lucide-react"

export default function Header() {
  return (
    <header className="border-b border-slate-800 bg-slate-950 px-6 py-4 dark:bg-slate-950">
      <div className="flex items-center justify-center gap-3">
        <div className="flex items-center gap-2">
          <Activity className="w-6 h-6 text-cyan-400 animate-pulse" />
          <h1 className="text-xl font-bold text-slate-100">Self-Healing Test Server</h1>
        </div>
      </div>
    </header>
  )
}
