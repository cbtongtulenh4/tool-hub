"use client"

import { useEffect, useState } from "react"

interface StreamingLogLineProps {
  text: string
  isError?: boolean
  isSuccess?: boolean
  isHealing?: boolean
  onComplete?: () => void
}

export default function StreamingLogLine({ text, isError, isSuccess, isHealing, onComplete }: StreamingLogLineProps) {
  const [displayedText, setDisplayedText] = useState("")
  const [isStreaming, setIsStreaming] = useState(true)

  useEffect(() => {
    if (!isStreaming) return

    if (displayedText.length < text.length) {
      const timer = setTimeout(() => {
        setDisplayedText(text.slice(0, displayedText.length + 1))
      }, 15) // 15ms per character for smooth streaming

      return () => clearTimeout(timer)
    } else {
      setIsStreaming(false)
      onComplete?.()
    }
  }, [displayedText, text, isStreaming, onComplete])

  const colorClass = isError
    ? "text-red-400"
    : isSuccess
      ? "text-green-400"
      : isHealing
        ? "text-amber-400"
        : "text-slate-400"

  return (
    <div className={`font-mono text-xs leading-relaxed whitespace-pre-wrap break-words ${colorClass}`}>
      {displayedText}
      {isStreaming && <span className="animate-pulse">▌</span>}
    </div>
  )
}
